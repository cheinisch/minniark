# Image Portfolio
Da Koken.me 2018/2019 eingestellt wurde, ist das ein Versuch, ein eigenes CMS zu erstellen um Bilder und Texte zu präsentieren.

Aktuell wird an der Admingui gearbeitet

Es gibt ein Basislayout mit dem Namen "Basic"

Es können Essays neu erstellt werden

Essays und alben können bearbeitet werden

nächster Step ist das anlegen von Alben und Bilder hochladen

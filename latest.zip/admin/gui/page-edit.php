<?php

  if(isset($_GET['page']))
  {
    if($_GET['page'] == 'page-update')
    {
      update_page($_POST['title'], $_POST['content'], $_GET['id']);
      header("Location: admin.php?page=page-edit&id=".$_GET['id']);
    }elseif($_GET['page'] == 'page-create')
    {
      create_page($_POST['title'], $_POST['content']);
    }elseif($_GET['page'] == 'page-new')
    {
?>

      
     
<h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
          <span>pages</span>
          <a class="link-secondary" href="#" aria-label="Add a new report">
            <span data-feather="plus-circle"></span>
          </a>
        </h6>
        <ul class="nav flex-column mb-2">
        <?php
            $pagelist = get_pages();
            while($row = $pagelist->fetch_assoc())
            {
              ?>
              <li class="nav-item">
            <a class="nav-link" href="admin.php?page=page-detail&id=<?php echo $row["id"]; ?>">
              <span data-feather="file-text"></span>
              <?php echo $row["content_title"]; ?>
            </a>
          </li>
              <?php
            }

        ?>
        </ul>
        </div>
    </nav>
    <main class="col-md-8 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">pages</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group me-2">
        <form action="admin.php?page=page-create" method="post">
        <button type="submit" class="btn btn-sm btn-outline-danger">Save</button>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-6">
      <div class="form-group">

      <label for="title">Title:</label>
        <input type="text" id="title" placeholder="Title" autocomplete="off" class="form-control" name="title"/>
      </div>
      <label for="content">Content:</label> 
      <textarea name="content" id="editor" placeholder="pagetext">
      
      </textarea>
          </form>
      <script>
        ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
        console.error( error );
        } );
      </script>
    </main>

<?php
    }else{
      ?>

      
     
     <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
          <span>pages</span>
          <a class="link-secondary" href="#" aria-label="Add a new report">
            <span data-feather="plus-circle"></span>
          </a>
        </h6>
        <ul class="nav flex-column mb-2">
        <?php
            $pagelist = get_pages();
            while($row = $pagelist->fetch_assoc())
            {
              ?>
              <li class="nav-item">
            <a class="nav-link" href="admin.php?page=page-detail&id=<?php echo $row["id"]; ?>">
              <span data-feather="file-text"></span>
              <?php echo $row["content_title"]; ?>
            </a>
          </li>
              <?php
            }

        ?>
        </ul>
        </div>
    </nav>
    <main class="col-md-8 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">pages</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group me-2">
        <form action="admin.php?page=page-update&id=<?php echo $_GET['id']; ?>" method="post">
        <button type="submit" class="btn btn-sm btn-outline-danger">Save</button>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-6">
      <div class="form-group">

      <?php
        $row = get_page($_GET['id']);
        $page = $row->fetch_assoc();
      ?>

      <label for="title">Title:</label>
        <input type="text" id="title" placeholder="Title" autocomplete="off" class="form-control" name="title" value="<?php echo $page["content_title"]; ?>"/>
      </div>
      <label for="content">Content:</label> 
      <textarea name="content" id="editor">
      <?php echo $page["content_text"]; ?>
      </textarea>
          </form>
      <script>
        ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
        console.error( error );
        } );
      </script>
    </main>
    <?php
    }
  }


?>
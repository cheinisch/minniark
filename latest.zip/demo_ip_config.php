<?php

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for ImagePortfolio */
define( 'DB_NAME', '' );
/** MySQL database username */
define( 'DB_USER', '' );
/** MySQL database password */
define( 'DB_PASSWORD', '' );
/** MySQL hostname */
define( 'DB_HOST', '' );

define('DB_PREFIX','');
?>
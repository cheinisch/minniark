<?php

include "admin/inc/functions.php";

$theme = pcs_get_theme_path();



if (isset($_GET['content']))
{
    if($_GET['content'] == 'essays')
    {
        //include $theme."essay.php";
        pcs_get_essays();
    }elseif($_GET['content'] == 'essay')
    {
        include $theme."essay.php";
        //pcs_get_essays();
    }elseif($_GET['content'] == 'albums')
    {
        include $theme."albums.php";
        //pcs_get_albums
    }
    elseif($_GET['content'] == 'album')
    {
        include $theme."album.php";
    }
    elseif($_GET['content'] == 'single-image')
    {
        include $theme."single-image.php";
    }elseif($_GET['content'] == 'page')
    {
        include $theme."page.php";
    }
}else{
    include $theme."timeline.php";
}

?>
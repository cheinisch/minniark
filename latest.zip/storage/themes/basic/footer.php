
        <hr />
        <footer>
            <p>Copyright <?php echo ip_get_sitecopyright(); ?></p>
        </footer>
        
        </div>
        <script async src="https://cdn.jsdelivr.net/npm/masonry-layout@4.2.2/dist/masonry.pkgd.min.js" integrity="sha384-GNFwBvfVxBkLMJpYMOABq3c+d3KnQxudP/mGPkzpZSTYykLBNsZEnG2D9G/X/+7D" crossorigin="anonymous"></script>
    </body>
</html>
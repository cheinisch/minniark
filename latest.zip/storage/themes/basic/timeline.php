<?php
include $theme."header.php";
?>

<?php
    include $theme."footer.php";
    ?>
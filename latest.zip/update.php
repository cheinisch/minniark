<?php

/*
Update functions
1. get latest zip archiv
2. delete all data but not the storage folder
3. unzip the latest archiv
4. check database for an update
5. update database
6. reload admin interface
*/


// functions

function get_latest_archiv()
{

}

function delete_data()
{

}

function unzip()
{

}

function update_database()
{
    
}

?>